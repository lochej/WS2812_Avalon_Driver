#!/bin/bash

shell=/home/fpga/intelFPGA_lite/18.1/nios2eds/nios2_command_shell.sh
$shell nios2-configure-sof -d 2 output_files/nios2_BaseSys.sof
$shell nios2-download -g -d 2 software/HelloWorld_Nios2/HelloWorld_Nios2.elf