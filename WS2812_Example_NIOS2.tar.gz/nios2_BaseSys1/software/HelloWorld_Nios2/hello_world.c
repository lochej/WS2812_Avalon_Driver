/*
 * mainc.c
 *
 *  Created on: Nov 7, 2019
 *      Author: LOCHE Jeremy
 */
#include <stdio.h> //std lib
#include <stdlib.h>
#include <stdint.h> //usefull uint32_t etc types
#include <sys/time.h> //usleep and sleep
#include "system.h"
#include "ws2812_driver.h"



#define NUM_LEDS 24

void *ws2812_base=WS2812_DRIVER_0_BASE;

uint8_t power=0x10;
uint8_t animation=0;

uint32_t raindow[7]={0x9400D3,0x4B0082,0x0000FF,0x00FF00,0xFFFF00,0xFF7F00,0xFF0000};

uint8_t barB_id(uint8_t id_bar)
{
	return 7-id_bar;
}

uint8_t barUL_id(uint8_t id_bar)
{
	return 16 + id_bar;
}

uint8_t barUR_id(uint8_t id_bar)
{
	return 8 + id_bar;
}

uint8_t bar_id(uint8_t bar, uint8_t pix)
{
	switch(bar)
	{
	case 0:
		return barB_id(pix);
	case 1:
		return barUL_id(pix);
	case 2:
		return barUR_id(pix);
	}
	return 0;
}
void clearLeds()
{
	for(uint8_t i=0;i<NUM_LEDS;i++)
	{
		//leds[i]=0;
		WS2812_SET_RGB(ws2812_base,i,0);
	}
}

void setBar(uint8_t bar,uint8_t mask,uint32_t color)
{

	for(uint8_t i=0;i<8;i++)
	{
		if(mask & (1<<i))
		{
			//leds[bar_id(bar,i)]=color;
			WS2812_SET_RGB(ws2812_base,bar_id(bar,i),color);
		}
		else
		{
			//leds[bar_id(bar,i)]=0;
			WS2812_SET_RGB(ws2812_base,bar_id(bar,i),0);
		}

	}
}

void Process_Flux_Capacitor()
{

	static uint8_t id=7;

	while(!WS2812_IDLE(ws2812_base));

	id--;
	for(uint8_t bar=0;bar<3;bar++)
	{
		setBar(bar,1<<id,WS2812_SCALE8(0xFFFFFF,power));
	}

	if(id==0)
		id=8;

	WS2812_SYNC(ws2812_base);

	usleep(45*1000);

}


void Process_Rainbow()
{
	static uint8_t hue=0;

	while(!WS2812_IDLE(ws2812_base));

	for(uint8_t i=0;i<3;i++)
	{
		for(uint8_t j=0;j<8;j++)
		{
			uint8_t id=(hue+j)%7;

			//IOWR(ws2812_addr,3+bar_id(i,j),WS2812_SCALE8(WS2812_RGB_TO_GRB(raindow[id]),power));

			WS2812_SET_RGB(ws2812_base,bar_id(i,j),WS2812_SCALE8(raindow[id],power));
			//leds[bar_id(i,j)]=WS2812_SCALE8(WS2812_RGB_TO_GRB(raindow[id]),0x08);
		}

	}

	hue++;

	//ws2812_sync();
	//IOWR(ws2812_addr,1,0x3); //send SYNC
	WS2812_SYNC(ws2812_base);

	//Systick_delayms(50);
	usleep(60*1000);

}

int main(int argc,char **argv)
{
	printf("WS2812 driving starting\n");
/*
	void *virtual_base;
	int fd;

	if(argc !=3)
	{
		printf("Error argument : argv[1] = animation argv[2] = intensity");
		return -1;
	}
	*/

	power = 0x10 ;//strtol(argv[2],NULL,16);
	animation = 1;//strtol(argv[1],NULL,10);


	WS2812_RESET(ws2812_base);

	WS2812_SET_LEDNUMBER(ws2812_base,NUM_LEDS);
	printf("LED number = %d\n",WS2812_GET_LEDNUMBER(ws2812_base));

	WS2812_SET_RGB(ws2812_base,0,0xA0A0A0);

	printf("RGB read = %06X\n",WS2812_GET_RGB(ws2812_base,0));

	printf("Set led number OK\n");

	while(1)
	{
		switch(animation)
		{
		case 0:
			Process_Flux_Capacitor();
			break;
		case 1:
		default:
			Process_Rainbow();
			break;
		}

	}

	return 0;
}




#if 0
/*
 * "Hello World" example.
 *
 * This example prints 'Hello from Nios II' to the STDOUT stream. It runs on
 * the Nios II 'standard', 'full_featured', 'fast', and 'low_cost' example
 * designs. It runs with or without the MicroC/OS-II RTOS and requires a STDOUT
 * device in your system's hardware.
 * The memory footprint of this hosted application is ~69 kbytes by default
 * using the standard reference design.
 *
 * For a reduced footprint version of this template, and an explanation of how
 * to reduce the memory footprint for a given application, see the
 * "small_hello_world" template.
 *
 */

#include <stdio.h>
#include <stdint.h>
#include "io.h"
#include "system.h"

#define WS2812_RGB_TO_GRB(rgb) (((rgb) &0xFF0000)>>8 | ((rgb) & 0x00FF00) << 8|((rgb)&0x0000FF))
#define WS2812_SCALE8(rgb,scale)  (((((rgb)>>16)&0xFF)*(scale)/0xFF)<<16) | (((((rgb)>>8)&0xFF)*(scale)/0xFF)<<8) | (((((rgb)>>0)&0xFF)*(scale)/0xFF)<<0)

#define NUM_LEDS 24
volatile uint32_t leds[NUM_LEDS]={0};

uint32_t raindow[7]={0x9400D3,0x4B0082,0x0000FF,0x00FF00,0xFFFF00,0xFF7F00,0xFF0000};

uint8_t barB_id(uint8_t id_bar)
{
	return 7-id_bar;
}

uint8_t barUL_id(uint8_t id_bar)
{
	return 16 + id_bar;
}

uint8_t barUR_id(uint8_t id_bar)
{
	return 8 + id_bar;
}

uint8_t bar_id(uint8_t bar, uint8_t pix)
{
	switch(bar)
	{
	case 0:
		return barB_id(pix);
	case 1:
		return barUL_id(pix);
	case 2:
		return barUR_id(pix);
	}
	return 0;
}
void clearLeds()
{
	for(uint8_t i=0;i<NUM_LEDS;i++)
	{
		leds[i]=0;
	}
}

void setBar(uint8_t bar,uint8_t mask,uint32_t color)
{

	uint32_t r,g,b;
	r=0x0F;
	g=0x0F;
	b=0x0F;
	for(uint8_t i=0;i<8;i++)
	{
		if(mask & (1<<i))
		{
			//leds[bar_id(bar,i)]=color;
			IOWR(WS2812_DRIVER_0_BASE,3+bar_id(bar,i),color);
		}
		else
		{

			IOWR(WS2812_DRIVER_0_BASE,3+bar_id(bar,i),0);
		}

	}
}

void Process_Flux_Capacitor()
{

	static uint8_t id=7;


	while(!IORD(WS2812_DRIVER_0_BASE,0));

	id--;
	for(uint8_t bar=0;bar<3;bar++)
	{
		setBar(bar,1<<id,0x040404);

	}

	if(id==0)
		id=8;

	//ws2812_sync();
	IOWR(WS2812_DRIVER_0_BASE,1,0x2); //send SYNC

	usleep(100*1000);

}
/*
void Process_Tornado()
{
	static uint8_t id=0;


	clearLeds();

	setBar(id%3,1<<(id/3),0x0F<<((id%3)*8));

	id++;
	if(id>24)
		id=0;

	while(!WS2812_IDLE());
	ws2812_sync();

	Systick_delayms((id/3)*25);

}
*/

void Process_Rainbow()
{
	static uint8_t hue=0;

	while(!IORD(WS2812_DRIVER_0_BASE,0));

	for(uint8_t i=0;i<3;i++)
	{
		for(uint8_t j=0;j<8;j++)
		{
			uint8_t id=(hue+j)%7;

			IOWR(WS2812_DRIVER_0_BASE,3+bar_id(i,j),WS2812_SCALE8(WS2812_RGB_TO_GRB(raindow[id]),0x08));
			//leds[bar_id(i,j)]=WS2812_SCALE8(WS2812_RGB_TO_GRB(raindow[id]),0x08);
		}

	}

	hue++;

	//ws2812_sync();
	IOWR(WS2812_DRIVER_0_BASE,1,0x2); //send SYNC

	//Systick_delayms(50);
	usleep(100*1000);

}


int main()
{
	printf("Hello from JLH Nios II!\r\n");


	//IOWR(WS2812_DRIVER_0_BASE,1,0x3);
#if 1
	unsigned long value=0x100000;
	for(unsigned int i=0;i<24;i++)
	{
		printf("Write LED: %d -> %d\n",i,value);
		IOWR(WS2812_DRIVER_0_BASE,3+i,i%2 == 0 ? value :0x001000);
	}

	for(unsigned int i=0;i<24;i++)
	{
		printf("Read LED: %d -> %d\n",i,IORD(WS2812_DRIVER_0_BASE,3+i));
	}

	IOWR(WS2812_DRIVER_0_BASE,1,0x0);
	printf("RESETTING Driver\n");
	printf("READ RESET %d\n",IORD(WS2812_DRIVER_0_BASE,1));

	IOWR(WS2812_DRIVER_0_BASE,1,0x1); //reset request
	printf("RELEASING reset\n");

	printf("READ RESET %d\n",IORD(WS2812_DRIVER_0_BASE,1));

	IOWR(WS2812_DRIVER_0_BASE,2,24); //4 leds setup
	printf("READ leds %d\n",IORD(WS2812_DRIVER_0_BASE,2));


	//IOWR(WS2812_DRIVER_0_BASE,1,0x3); //send SYNC


	while(1)
	{

		//Process_Rainbow();
		Process_Flux_Capacitor();
		/*
		for(unsigned int i=0;i<24;i++)
		{

			IOWR(WS2812_DRIVER_0_BASE,3+i,i%2 == 0 ? value :0);
		}

		IOWR(WS2812_DRIVER_0_BASE,1,0x3); //send SYNC
		while(!IORD(WS2812_DRIVER_0_BASE,0));
		usleep(100000);

		for(unsigned int i=0;i<24;i++)
		{
			IOWR(WS2812_DRIVER_0_BASE,3+i,i%2 == 1 ? 0x001000 :0);
		}

		//for(unsigned int i=0;i<12;i++)
		//	IOWR(WS2812_DRIVER_0_BASE,3+i,i%2 == 1 ? 0x101010 : 0x100010);

		IOWR(WS2812_DRIVER_0_BASE,1,0x3); //send SYNC

		while(!IORD(WS2812_DRIVER_0_BASE,0));
		usleep(100000);
		*/
	}
#endif
	return 0;
}
#endif
